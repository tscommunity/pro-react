import { createBrowserRouter } from "react-router-dom";
import App from "./App.tsx";
import {
  BreadcrumbDemo,
  ButtonDemo,
  Common,
  DataInput,
  DataPresentation,
  DropdownDemo,
  Feedback,
  IconDemo,
  Layout,
  LayoutDemo,
  MenuDemo,
  Navigation,
  SpaceDemo,
  StepsDemo,
} from "./components/index.ts";
import { About } from "./views/index.ts";
import { PaginationDemo } from "./components/PaginationDemo/PaginationDemo.tsx";
import { AutoCompleteDemo, CascaderDemo, CheckboxDemo, FormDemo, InputDemo, InputNumberDemo, RadioDemo, RateDemo, SelectDemo, SliderDemo, SwitchDemo, TimePickerDemo, TransferDemo, TreeSelectDemo, UploadDemo } from "./components/DataInput/components/index.ts";
import { AvatarDemo, BadgeDemo, CalendarDemo, CardDemo, CarouselDemo, CollapseDemo, DescriptionsDemo, ImageDemo, ListDemo, PopoverDemo, SegmentedDemo, StatisticDemo, TableDemo, TabsDemo, TagDemo, TimelineDemo, TooltipDemo, TourDemo, TreeDemo } from "./components/DataPresentation/components/index.ts";
import { DrawerDemo, MessageDemo, ModalDemo } from "./components/Feedback/components/index.ts";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "/about",
        element: <About />,
      },
      {
        path: "/common",
        element: <Common />,
        children: [
          {
            path: "/common/button",
            element: <ButtonDemo />,
          },
          {
            path: "/common/icon",
            element: <IconDemo />,
          },
        ],
      },
      {
        path: "/layout",
        element: <Layout />,
        children: [
          {
            path: "/layout/layout",
            element: <LayoutDemo />,
          },
          {
            path: "/layout/space",
            element: <SpaceDemo />,
          },
        ],
      },
      {
        path: "/navigation",
        element: <Navigation />,
        children: [
          {
            path: "/navigation/breadcrumb",
            element: <BreadcrumbDemo />,
          },
          {
            path: "/navigation/menu",
            element: <MenuDemo />,
          },
          {
            path: "/navigation/pagination",
            element: <PaginationDemo />,
          },
          {
            path: "/navigation/steps",
            element: <StepsDemo />,
          },
          {
            path: "/navigation/dropdown",
            element: <DropdownDemo />,
          },
        ],
      },
      {
        path: "/datainput",
        element: <DataInput />,
        children: [
          {
            path: "/datainput/autocomplete",
            element: <AutoCompleteDemo />,
          },
          {
            path: "/datainput/cascader",
            element: <CascaderDemo />,
          },
          {
            path: "/datainput/input",
            element: <InputDemo />,
          },
          {
            path: "/datainput/inputnumber",
            element: <InputNumberDemo />,
          },
          {
            path: "/datainput/select",
            element: <SelectDemo />,
          },
          {
            path: "/datainput/slider",
            element: <SliderDemo />,
          },
          {
            path: "/datainput/rate",
            element: <RateDemo />,
          },
          {
            path: "/datainput/radio",
            element: <RadioDemo />,
          },
          {
            path: "/datainput/switch",
            element: <SwitchDemo />,
          },
          {
            path: "/datainput/timepicker",
            element: <TimePickerDemo />,
          },
          {
            path: "/datainput/treeselect",
            element: <TreeSelectDemo />,
          },
          {
            path: "/datainput/transfer",
            element: <TransferDemo />,
          },
          {
            path: "/datainput/form",
            element: <FormDemo />,
          },
          {
            path: "/datainput/upload",
            element: <UploadDemo />,
          },
          {
            path: "/datainput/checkbox",
            element: <CheckboxDemo />,
          },
        ],
      },
      {
        path: "/datapresentation",
        element: <DataPresentation />,
        children: [
          {
            path: "/datapresentation/avatar",
            element: <AvatarDemo />,
          },
          {
            path: "/datapresentation/badge",
            element: <BadgeDemo />,
          },
          {
            path: "/datapresentation/card",
            element: <CardDemo />,
          },
          {
            path: "/datapresentation/calendar",
            element: <CalendarDemo />,
          },
          {
            path: "/datapresentation/carousel",
            element: <CarouselDemo />,
          },
          {
            path: "/datapresentation/collapse",
            element: <CollapseDemo />,
          },
          {
            path: "/datapresentation/descriptions",
            element: <DescriptionsDemo />,
          },
          {
            path: "/datapresentation/list",
            element: <ListDemo />,
          },
          {
            path: "/datapresentation/popover",
            element: <PopoverDemo />,
          },
          {
            path: "/datapresentation/image",
            element: <ImageDemo />,
          },
          {
            path: "/datapresentation/segmented",
            element: <SegmentedDemo />,
          },
          {
            path: "/datapresentation/statistic",
            element: <StatisticDemo />,
          },
          {
            path: "/datapresentation/table",
            element: <TableDemo />,
          },
          {
            path: "/datapresentation/tabs",
            element: <TabsDemo />,
          },
          {
            path: "/datapresentation/tag",
            element: <TagDemo />,
          },
          {
            path: "/datapresentation/timeline",
            element: <TimelineDemo />,
          },
          {
            path: "/datapresentation/tooltip",
            element: <TooltipDemo />,
          },
          {
            path: "/datapresentation/tour",
            element: <TourDemo />,
          },
          {
            path: "/datapresentation/tree",
            element: <TreeDemo />,
          },
        ],
      },
      {
        path: "/feedback",
        element: <Feedback />,
        children: [
          {
            path: "/feedback/message",
            element: <MessageDemo />
          },
          {
            path: "/feedback/modal",
            element: <ModalDemo />
          },
          {
            path: "/feedback/drawer",
            element: <DrawerDemo />
          },
        ],
      },
    ],
  },
]);
