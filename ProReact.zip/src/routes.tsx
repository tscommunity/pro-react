import { createBrowserRouter } from "react-router-dom";
import App from "./App.tsx";
import {
  BreadcrumbDemo,
  ButtonDemo,
  Common,
  DataInput,
  DataPresentation,
  DropdownDemo,
  IconDemo,
  Layout,
  LayoutDemo,
  MenuDemo,
  Navigation,
  SpaceDemo,
  StepsDemo,
} from "./components/index.ts";
import { About } from "./views/index.ts";
import { PaginationDemo } from "./components/PaginationDemo/PaginationDemo.tsx";
import { AutoCompleteDemo, CascaderDemo, CheckboxDemo, FormDemo, InputDemo, InputNumberDemo, RadioDemo, RateDemo, SelectDemo, SliderDemo, SwitchDemo, TimePickerDemo, TransferDemo, TreeSelectDemo, UploadDemo } from "./components/DataInput/components/index.ts";
import { AvatarDemo, BadgeDemo, CalendarDemo, CardDemo, CarouselDemo } from "./components/DataPresentation/components/index.ts";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "/about",
        element: <About />,
      },
      {
        path: "/common",
        element: <Common />,
        children: [
          {
            path: "/common/button",
            element: <ButtonDemo />,
          },
          {
            path: "/common/icon",
            element: <IconDemo />,
          },
        ],
      },
      {
        path: "/layout",
        element: <Layout />,
        children: [
          {
            path: "/layout/layout",
            element: <LayoutDemo />,
          },
          {
            path: "/layout/space",
            element: <SpaceDemo />,
          },
        ],
      },
      {
        path: "/navigation",
        element: <Navigation />,
        children: [
          {
            path: "/navigation/breadcrumb",
            element: <BreadcrumbDemo />,
          },
          {
            path: "/navigation/menu",
            element: <MenuDemo />,
          },
          {
            path: "/navigation/pagination",
            element: <PaginationDemo />,
          },
          {
            path: "/navigation/steps",
            element: <StepsDemo />,
          },
          {
            path: "/navigation/dropdown",
            element: <DropdownDemo />,
          },
        ],
      },
      {
        path: "/datainput",
        element: <DataInput />,
        children: [
          {
            path: "/datainput/autocomplete",
            element: <AutoCompleteDemo />,
          },
          {
            path: "/datainput/cascader",
            element: <CascaderDemo />,
          },
          {
            path: "/datainput/input",
            element: <InputDemo />,
          },
          {
            path: "/datainput/inputnumber",
            element: <InputNumberDemo />,
          },
          {
            path: "/datainput/select",
            element: <SelectDemo />,
          },
          {
            path: "/datainput/slider",
            element: <SliderDemo />,
          },
          {
            path: "/datainput/rate",
            element: <RateDemo />,
          },
          {
            path: "/datainput/radio",
            element: <RadioDemo />,
          },
          {
            path: "/datainput/switch",
            element: <SwitchDemo />,
          },
          {
            path: "/datainput/timepicker",
            element: <TimePickerDemo />,
          },
          {
            path: "/datainput/treeselect",
            element: <TreeSelectDemo />,
          },
          {
            path: "/datainput/transfer",
            element: <TransferDemo />,
          },
          {
            path: "/datainput/form",
            element: <FormDemo />,
          },
          {
            path: "/datainput/upload",
            element: <UploadDemo />,
          },
          {
            path: "/datainput/checkbox",
            element: <CheckboxDemo />,
          },
        ],
      },
      {
        path: "/datapresentation",
        element: <DataPresentation />,
        children:[
          {
            path: "/datapresentation/avatar",
            element: <AvatarDemo />,
          },
          {
            path: "/datapresentation/badge",
            element: <BadgeDemo />,
          },
          {
            path: "/datapresentation/card",
            element: <CardDemo />,
          },
          {
            path: "/datapresentation/calendar",
            element: <CalendarDemo />,
          },
          {
            path: "/datapresentation/carousel",
            element: <CarouselDemo />,
          },
        ],

      },
    ],
  },
]);
