import { Layout, Menu, MenuProps } from "antd";
import { Header, Content, Footer } from "antd/es/layout/layout";
import Sider from "antd/es/layout/Sider";
import { useState } from "react";
import { Outlet } from "react-router-dom";

type MenuItem = Required<MenuProps>["items"][number];

export interface ClassicLayoutProps {
  header?: React.ReactElement;
  footer?: React.ReactElement;
  menus?: Array<MenuItem>;
}

export default function ClassicLayout({
  header,
  footer,
  menus,
}: Readonly<ClassicLayoutProps>): React.ReactElement {
  const headerStyle: React.CSSProperties = {
    textAlign: "center",
    height: 64,
    paddingInline: 48,
    lineHeight: "64px",
    position: "sticky",
    top: 0,
  };

  const contentStyle: React.CSSProperties = {
    // textAlign: "center",
    minHeight: 120,
    lineHeight: "120px",
    padding: "20px",
    backgroundColor: "white",
    margin: "0 20px 20px 20px",
  };

  const siderStyle: React.CSSProperties = {
    textAlign: "center",
    lineHeight: "120px",
    position: "sticky",
    top: "64px",
  };

  const footerStyle: React.CSSProperties = {
    textAlign: "center",
  };

  const layoutStyle = {
    borderRadius: 0,
    // overflow: "hidden",
    // height: "100%",
  };

  const [current, setCurrent] = useState("mail");

  const onClick: MenuProps["onClick"] = (e) => {
    console.log("click ", e);
    setCurrent(e.key);
  };

  return (
    <Layout style={layoutStyle}>
      {header && <Header style={headerStyle}>{header}</Header>}
      <Layout>
        <Sider width="200" style={siderStyle}>
          {menus && <Menu onClick={onClick} selectedKeys={[current]} mode="inline" items={menus} />}
        </Sider>
        <Content style={contentStyle}>
          <Outlet />
        </Content>
      </Layout>
      {footer && <Footer style={footerStyle}>{footer}</Footer>}
    </Layout>
  );
}
