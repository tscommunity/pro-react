import { ConfigProvider, MenuProps, ThemeConfig } from "antd";
import { AppstoreOutlined, MailOutlined, SettingOutlined } from "@ant-design/icons";
import "./App.scss";
import ClassicLayout from "./layouts/ClassicLayout/ClassicLayout";

const Header = () => <div>这是头部</div>;

function App() {
  const customTheme: Partial<ThemeConfig> = {
    token: {
      borderRadius: 0,
      controlOutline: "none",
      controlOutlineWidth: 0,
    },
  };

  type MenuItem = Required<MenuProps>["items"][number];

  const menus: MenuItem[] = [
    {
      label: "组件总览",
      key: "overview",
      icon: <AppstoreOutlined />,
    },
    {
      label: "通用",
      key: "common",
      children: [
        {
          label: <a href="/common/button">Button 按钮</a>,
          key: "common-button",
        },
        {
          label: <a href="/common/icon">Icon 图标</a>,
          key: "common-icon",
        },
      ],
    },
    {
      label: "布局",
      key: "layout",
      children: [
        {
          label: <a href="/layout/divider">Divider 分割线</a>,
          key: "layout-divider",
        },
        {
          label: <a href="/layout/grid">Grid 栅格</a>,
          key: "layout-grid",
        },
        {
          label: <a href="/layout/layout">Layout 布局</a>,
          key: "layout-layout",
        },
        {
          label: <a href="/layout/space">Space 间距</a>,
          key: "layout-space",
        },
      ],
    },
    {
      label: "导航",
      key: "navigation",
      children: [
        {
          label: <a href="/navigation/breadcrumb">Breadcrumb 面包屑</a>,
          key: "navigation-breadcrumb",
        },
        {
          label: <a href="/navigation/dropdown">Dropdown 下拉菜单</a>,
          key: "navigation-dropdown",
        },
        {
          label: <a href="/navigation/menu">Menu 导航菜单</a>,
          key: "navigation-menu",
        },
        {
          label: <a href="/navigation/pagination">Pagination 分页</a>,
          key: "navigation-pagination",
        },
        {
          label: <a href="/navigation/steps">Steps 步骤条</a>,
          key: "navigation-steps",
        },
      ],
    },
    {
      label: "数据录入",
      key: "data-input",
      children: [
        {
          label: <a href="/datainput/autocomplete">AutoComplete 自动完成</a>,
          key: "datainput-autocomplete",
        },
        {
          label: <a href="/datainput/cascader">Cascader 级联选择</a>,
          key: "datainput-cascader",
        },
        {
          label: <a href="/datainput/input">Input 输入框</a>,
          key: "datainput-input",
        },
        {
          label: <a href="/datainput/inputnumber">InputNumber 数字输入框</a>,
          key: "datainput-inputnumber",
        },
        {
          label: <a href="/datainput/select">Select 选择器</a>,
          key: "datainput-select",
        },
        {
          label: <a href="/datainput/slider">Slider 滑动输入条</a>,
          key: "datainput-slider",
        },
        {
          label: <a href="/datainput/rate">Rate 评分</a>,
          key: "datainput-rate",
        },
        {
          label: <a href="/datainput/radio">Radio 单选</a>,
          key: "datainput-radio",
        },
        {
          label: <a href="/datainput/switch">Switch 开关</a>,
          key: "datainput-switch",
        },
        {
          label: <a href="/datainput/timepicker">TimePicker 时间选择器</a>,
          key: "datainput-timepicker",
        },
        {
          label: <a href="/datainput/treeselect">TreeSelect 树选择</a>,
          key: "datainput-treeselect",
        },
        {
          label: <a href="/datainput/transfer">Transfer 穿梭框</a>,
          key: "datainput-transfer",
        },
        {
          label: <a href="/datainput/form">Form 表单</a>,
          key: "datainput-form",
        },
        {
          label: <a href="/datainput/upload">Upload 上传</a>,
          key: "datainput-upload",
        },
        {
          label: <a href="/datainput/checkbox">Checkbox 多选框</a>,
          key: "datainput-checkbox",
        },
      ],
    },
    {
      label: "数据展示",
      key: "data-presentation",
      children: [
        {
          label: <a href="/datapresentation/avatar">Avatar 头像</a>,
          key: "datapresentation-avatar",
        },
        {
          label: <a href="/datapresentation/badge">Badge 徽标数</a>,
          key: "datapresentation-badge",
        },
        {
          label: <a href="/datapresentation/card">Card 卡片</a>,
          key: "datapresentation-card",
        },
        {
          label: <a href="/datapresentation/calendar">Calendar 日历</a>,
          key: "datapresentation-calendar",
        },
        {
          label: <a href="/datapresentation/carousel">Carousel 走马灯</a>,
          key: "datapresentation-carousel",
        },
      ],
    },
    {
      label: "反馈",
      key: "feedback",
      children: [],
    },
    {
      label: "其他",
      key: "others",
      children: [],
    },
  ];

  return (
    <ConfigProvider theme={customTheme}>
      <ClassicLayout header={<Header />} menus={menus} />
    </ConfigProvider>
  );
}

export default App;
