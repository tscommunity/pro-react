import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {LayoutDemo} from './LayoutDemo';

const meta: Meta<typeof LayoutDemo> = {
  component: LayoutDemo,
};

export default meta;

type Story = StoryObj<typeof LayoutDemo>;

export const Basic: Story = {args: {}};
