import React from 'react';

import {LayoutDemo} from '../LayoutDemo';

describe('<LayoutDemo />', () => {});
