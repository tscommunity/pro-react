import React from 'react';

import { PaginationDemo } from "../PaginationDemo";

describe("<PaginationDemo />", () => {});
