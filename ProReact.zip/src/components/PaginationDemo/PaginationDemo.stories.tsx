import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {PaginationDemo} from './PaginationDemo';

const meta: Meta<typeof PaginationDemo> = {
  component: PaginationDemo,
};

export default meta;

type Story = StoryObj<typeof PaginationDemo>;

export const Basic: Story = {args: {}};
