import { Pagination } from "antd";
import styles from "./PaginationDemo.module.scss";

export interface PaginationDemoProps {
  prop?: string;
}

export function PaginationDemo({ prop = "分页示例" }: Readonly<PaginationDemoProps>) {
  return (
    <>
      <div className={styles.PaginationDemo}>PaginationDemo {prop}</div>

      <Pagination defaultCurrent={6} total={500} />
    </>
  );
}
