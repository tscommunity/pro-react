import {
  HomeOutlined,
  SettingFilled,
  SmileOutlined,
  SyncOutlined,
  LoadingOutlined,
} from "@ant-design/icons";
import { Space } from "antd";
import styles from "./IconDemo.module.scss";

export interface IconDemoProps {
  prop?: string;
}

export function IconDemo({ prop = "default value" }: IconDemoProps) {
  return (
    <>
      <div>图标示例</div>
      <Space className={styles.IconDemo}>
        <HomeOutlined />
        <SettingFilled />
        <SmileOutlined />
        <SyncOutlined spin />
        <SmileOutlined rotate={180} />
        <LoadingOutlined />
      </Space>
    </>
  );
}
