import React from 'react';

import {IconDemo} from '../IconDemo';

describe('<IconDemo />', () => {});
