import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {IconDemo} from './IconDemo';

const meta: Meta<typeof IconDemo> = {
  component: IconDemo,
};

export default meta;

type Story = StoryObj<typeof IconDemo>;

export const Basic: Story = {args: {}};
