import React from 'react';

import {SpaceDemo} from '../SpaceDemo';

describe('<SpaceDemo />', () => {});
