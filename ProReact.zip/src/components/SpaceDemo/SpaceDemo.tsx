import { Button, Popconfirm, Space, Upload } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import styles from "./SpaceDemo.module.scss";

export interface SpaceDemoProps {
  prop?: string;
}

export function SpaceDemo({ prop = "default value" }: Readonly<SpaceDemoProps>) {
  return (
    <>
      <div className={styles.SpaceDemo}>SpaceDemo {prop}</div>;
      <Space>
        Space
        <Button type="primary">Button</Button>
        <Upload>
          <Button>
            <UploadOutlined /> Click to Upload
          </Button>
        </Upload>
        <Popconfirm title="Are you sure delete this task?" okText="Yes" cancelText="No">
          <Button>Confirm</Button>
        </Popconfirm>
      </Space>
    </>
  );
}
