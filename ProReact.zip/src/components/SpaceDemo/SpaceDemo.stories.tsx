import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {SpaceDemo} from './SpaceDemo';

const meta: Meta<typeof SpaceDemo> = {
  component: SpaceDemo,
};

export default meta;

type Story = StoryObj<typeof SpaceDemo>;

export const Basic: Story = {args: {}};
