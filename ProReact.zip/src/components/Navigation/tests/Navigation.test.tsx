import React from 'react';

import {Navigation} from '../Navigation';

describe('<Navigation />', () => {});
