import { Outlet } from "react-router-dom";
import styles from "./Navigation.module.scss";

export interface NavigationProps {
  prop?: string;
}

export function Navigation({ prop = "default value" }: Readonly<NavigationProps>) {
  return (
    <>
      <div className={styles.Navigation}>Navigation {prop}</div>
      <Outlet />
    </>
  );
}
