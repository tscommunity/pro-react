import { Outlet } from "react-router-dom";
import styles from "./Layout.module.scss";

export interface LayoutProps {
  prop?: string;
}

export function Layout({ prop = "default value" }: Readonly<LayoutProps>) {
  return (
    <>
      <div className={styles.Layout}>Layout {prop}</div>
      <Outlet />
    </>
  );
}
