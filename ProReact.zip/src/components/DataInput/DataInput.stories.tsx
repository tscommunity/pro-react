import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {DataInput} from './DataInput';

const meta: Meta<typeof DataInput> = {
  component: DataInput,
};

export default meta;

type Story = StoryObj<typeof DataInput>;

export const Basic: Story = {args: {}};
