import { Outlet } from "react-router-dom";
import styles from "./DataInput.module.scss";

export interface DataInputProps {
  prop?: string;
}

export function DataInput({ prop = "数据录入示例" }: Readonly<DataInputProps>) {
  return (
    <>
      <div className={styles.DataInput}>DataInput {prop}</div>
      <Outlet />
    </>
  );
}
