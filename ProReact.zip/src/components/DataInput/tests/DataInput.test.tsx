import React from 'react';

import {DataInput} from '../DataInput';

describe('<DataInput />', () => {});
