import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {InputDemo} from './InputDemo';

const meta: Meta<typeof InputDemo> = {
  component: InputDemo,
};

export default meta;

type Story = StoryObj<typeof InputDemo>;

export const Basic: Story = {args: {}};
