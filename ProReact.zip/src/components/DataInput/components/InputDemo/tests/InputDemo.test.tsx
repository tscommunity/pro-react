import React from 'react';

import {InputDemo} from '../InputDemo';

describe('<InputDemo />', () => {});
