import React, { useState } from "react";
import { AutoComplete, Input, Space } from "antd";
import type { AutoCompleteProps } from "antd";
import styles from "./AutoCompleteDemo.module.scss";

export interface AutoCompleteDemoProps {
  prop?: string;
}

const getRandomInt = (max: number, min = 0) => Math.floor(Math.random() * (max - min + 1)) + min;
const searchResult = (query: string) =>
  Array.from({ length: getRandomInt(5) })
    .join('.')
    .split('.')
    .map((_, idx) => {
      const category = `${query}${idx}`;
      return {
        value: category,
        label: (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
            }}
          >
            <span>
              Found {query} on{' '}
              <a
                href={`https://s.taobao.com/search?q=${query}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                {category}
              </a>
            </span>
            <span>{getRandomInt(200, 100)} results</span>
          </div>
        ),
      };
    });

export function AutoCompleteDemo({ prop = "自动完成示例" }: Readonly<AutoCompleteDemoProps>) {
  const [options, setOptions] = React.useState<AutoCompleteProps["options"]>([]);
  const handleSearch = (value: string) => {
    setOptions(() => {
      if (!value || value.includes("@")) {
        return [];
      }
      return ["gmail.com", "163.com", "qq.com"].map((domain) => ({
        label: `${value}@${domain}`,
        value: `${value}@${domain}`,
      }));
    });
  };

  const [options2, setOptions2] = useState<AutoCompleteProps['options']>([]);

  const handleSearch2 = (value: string) => {
    setOptions2(value ? searchResult(value) : []);
  };

  const onSelect = (value: string) => {
    console.log('onSelect', value);
  };

  return (
    <>
      <div className={styles.AutoCompleteDemo}>AutoCompleteDemo {prop}</div>

      <Space direction="horizontal">

        <AutoComplete
          style={{ width: 200 }}
          onSearch={handleSearch}
          placeholder="input here"
          options={options}
        />

        <AutoComplete
          popupMatchSelectWidth={252}
          style={{ width: 300 }}
          options={options2}
          onSelect={onSelect}
          onSearch={handleSearch2}
          size="large"
        >
          <Input.Search size="large" placeholder="input here" enterButton />
        </AutoComplete>
      </Space>
    </>
  );
}
