import React from 'react';

import {AutoCompleteDemo} from '../AutoCompleteDemo';

describe('<AutoCompleteDemo />', () => {});
