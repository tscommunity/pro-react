import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {AutoCompleteDemo} from './AutoCompleteDemo';

const meta: Meta<typeof AutoCompleteDemo> = {
  component: AutoCompleteDemo,
};

export default meta;

type Story = StoryObj<typeof AutoCompleteDemo>;

export const Basic: Story = {args: {}};
