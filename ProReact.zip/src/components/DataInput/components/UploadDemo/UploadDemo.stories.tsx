import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {UploadDemo} from './UploadDemo';

const meta: Meta<typeof UploadDemo> = {
  component: UploadDemo,
};

export default meta;

type Story = StoryObj<typeof UploadDemo>;

export const Basic: Story = {args: {}};
