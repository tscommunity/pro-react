import React from 'react';

import {UploadDemo} from '../UploadDemo';

describe('<UploadDemo />', () => {});
