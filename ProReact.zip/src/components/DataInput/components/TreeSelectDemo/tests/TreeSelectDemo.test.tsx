import React from 'react';

import {TreeSelectDemo} from '../TreeSelectDemo';

describe('<TreeSelectDemo />', () => {});
