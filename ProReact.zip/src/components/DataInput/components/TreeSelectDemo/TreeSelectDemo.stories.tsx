import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TreeSelectDemo} from './TreeSelectDemo';

const meta: Meta<typeof TreeSelectDemo> = {
  component: TreeSelectDemo,
};

export default meta;

type Story = StoryObj<typeof TreeSelectDemo>;

export const Basic: Story = {args: {}};
