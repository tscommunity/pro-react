import { Checkbox } from 'antd';
import type { GetProp } from 'antd';
import styles from './CheckboxDemo.module.scss';

export interface CheckboxDemoProps {
  prop?: string;
}

const onChange: GetProp<typeof Checkbox.Group, 'onChange'> = (checkedValues) => {
  console.log('checked = ', checkedValues);
};

const plainOptions = ['Apple', 'Pear', 'Orange'];

const options = [
  { label: 'Apple', value: 'Apple' },
  { label: 'Pear', value: 'Pear' },
  { label: 'Orange', value: 'Orange' },
];

const optionsWithDisabled = [
  { label: 'Apple', value: 'Apple' },
  { label: 'Pear', value: 'Pear' },
  { label: 'Orange', value: 'Orange', disabled: false },
];

export function CheckboxDemo({ prop = '多选框组件示例' }: Readonly<CheckboxDemoProps>) {
  return <>
    <div className={styles.CheckboxDemo}>CheckboxDemo {prop}</div>

    <Checkbox.Group options={plainOptions} defaultValue={['Apple']} onChange={onChange} />
    <br />
    <Checkbox.Group options={options} defaultValue={[{ label: 'Pear', value: 'Pear' }]} onChange={onChange} />
    <br />
    <Checkbox.Group
      options={optionsWithDisabled}
      disabled
      defaultValue={['Apple']}
      onChange={onChange}
    />
  </>;
}
