import React from 'react';

import {CheckboxDemo} from '../CheckboxDemo';

describe('<CheckboxDemo />', () => {});
