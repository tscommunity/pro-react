import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {FormDemo} from './FormDemo';

const meta: Meta<typeof FormDemo> = {
  component: FormDemo,
};

export default meta;

type Story = StoryObj<typeof FormDemo>;

export const Basic: Story = {args: {}};
