import React from 'react';

import {FormDemo} from '../FormDemo';

describe('<FormDemo />', () => {});
