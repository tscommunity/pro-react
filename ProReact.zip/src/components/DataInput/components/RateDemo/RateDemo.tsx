import { Rate } from 'antd';
import styles from './RateDemo.module.scss';

export interface RateDemoProps {
  prop?: string;
}

export function RateDemo({ prop = '评分组件示例' }: Readonly<RateDemoProps>) {
  return <>
    <div className={styles.RateDemo}>RateDemo {prop}</div>

    <Rate allowHalf defaultValue={2.5} />
  </>;
}
