import React from 'react';

import {RateDemo} from '../RateDemo';

describe('<RateDemo />', () => {});
