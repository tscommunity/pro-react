import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {RateDemo} from './RateDemo';

const meta: Meta<typeof RateDemo> = {
  component: RateDemo,
};

export default meta;

type Story = StoryObj<typeof RateDemo>;

export const Basic: Story = {args: {}};
