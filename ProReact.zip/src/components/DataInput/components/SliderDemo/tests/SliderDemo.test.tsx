import React from 'react';

import {SliderDemo} from '../SliderDemo';

describe('<SliderDemo />', () => {});
