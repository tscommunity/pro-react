import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {SliderDemo} from './SliderDemo';

const meta: Meta<typeof SliderDemo> = {
  component: SliderDemo,
};

export default meta;

type Story = StoryObj<typeof SliderDemo>;

export const Basic: Story = {args: {}};
