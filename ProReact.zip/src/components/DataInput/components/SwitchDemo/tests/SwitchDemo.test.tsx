import React from 'react';

import {SwitchDemo} from '../SwitchDemo';

describe('<SwitchDemo />', () => {});
