import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {SwitchDemo} from './SwitchDemo';

const meta: Meta<typeof SwitchDemo> = {
  component: SwitchDemo,
};

export default meta;

type Story = StoryObj<typeof SwitchDemo>;

export const Basic: Story = {args: {}};
