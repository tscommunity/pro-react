import { CheckOutlined, CloseOutlined } from '@ant-design/icons';
import { Space, Switch } from 'antd';

import styles from './SwitchDemo.module.scss';

export interface SwitchDemoProps {
  prop?: string;
}

export function SwitchDemo({ prop = '开关组件示例' }: Readonly<SwitchDemoProps>) {
  return <>
    <div className={styles.SwitchDemo}>SwitchDemo {prop}</div>

    <Space direction="vertical">
      <Switch checkedChildren="开启" unCheckedChildren="关闭" defaultChecked />
      <Switch checkedChildren="1" unCheckedChildren="0" />
      <Switch
        checkedChildren={<CheckOutlined />}
        unCheckedChildren={<CloseOutlined />}
        defaultChecked
      />
    </Space>
  </>;
}
