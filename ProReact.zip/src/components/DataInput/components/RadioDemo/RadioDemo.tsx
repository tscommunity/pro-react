import { Flex, Radio } from 'antd';
import type { CheckboxGroupProps } from 'antd/es/checkbox';
import styles from './RadioDemo.module.scss';

export interface RadioDemoProps {
  prop?: string;
}

const options: CheckboxGroupProps<string>['options'] = [
  { label: 'Apple', value: 'Apple' },
  { label: 'Pear', value: 'Pear' },
  { label: 'Orange', value: 'Orange' },
];

export function RadioDemo({ prop = '单选按钮示例' }: Readonly<RadioDemoProps>) {
  return <>
    <div className={styles.RadioDemo}>RadioDemo {prop}</div>;

    <Flex vertical gap="middle">
      <Radio.Group options={options} defaultValue="Apple" />
      <Radio.Group

        options={options}
        defaultValue="Apple"
        optionType="button"
        buttonStyle="solid"
      />
      <Radio.Group options={options} defaultValue="Pear" optionType="button" />
    </Flex>
  </>
}
