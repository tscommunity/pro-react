import React from 'react';

import {RadioDemo} from '../RadioDemo';

describe('<RadioDemo />', () => {});
