import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {RadioDemo} from './RadioDemo';

const meta: Meta<typeof RadioDemo> = {
  component: RadioDemo,
};

export default meta;

type Story = StoryObj<typeof RadioDemo>;

export const Basic: Story = {args: {}};
