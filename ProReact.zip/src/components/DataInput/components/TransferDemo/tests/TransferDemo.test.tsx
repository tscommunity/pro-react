import React from 'react';

import {TransferDemo} from '../TransferDemo';

describe('<TransferDemo />', () => {});
