import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TransferDemo} from './TransferDemo';

const meta: Meta<typeof TransferDemo> = {
  component: TransferDemo,
};

export default meta;

type Story = StoryObj<typeof TransferDemo>;

export const Basic: Story = {args: {}};
