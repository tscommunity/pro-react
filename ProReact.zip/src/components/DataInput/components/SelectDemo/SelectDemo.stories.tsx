import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {SelectDemo} from './SelectDemo';

const meta: Meta<typeof SelectDemo> = {
  component: SelectDemo,
};

export default meta;

type Story = StoryObj<typeof SelectDemo>;

export const Basic: Story = {args: {}};
