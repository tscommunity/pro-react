import React from 'react';

import {SelectDemo} from '../SelectDemo';

describe('<SelectDemo />', () => {});
