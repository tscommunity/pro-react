import { Select, Space } from 'antd';
import styles from './SelectDemo.module.scss';

export interface SelectDemoProps {
  prop?: string;
}

const handleChange = (value: string) => {
  console.log(`selected ${value}`);
};

export function SelectDemo({ prop = '下拉选择示例' }: Readonly<SelectDemoProps>) {
  return <>
    <div className={styles.SelectDemo}>SelectDemo {prop}</div>

    <Space wrap>
      <Select
        defaultValue="lucy"
        style={{ width: 120 }}
        onChange={handleChange}
        options={[
          { value: 'jack', label: 'Jack' },
          { value: 'lucy', label: 'Lucy' },
          { value: 'Yiminghe', label: 'yiminghe' },
          { value: 'disabled', label: 'Disabled', disabled: true },
        ]}
      />
      <Select
        defaultValue="lucy"
        style={{ width: 120 }}
        disabled
        options={[{ value: 'lucy', label: 'Lucy' }]}
      />
      <Select
        defaultValue="lucy"
        style={{ width: 120 }}
        loading
        options={[{ value: 'lucy', label: 'Lucy' }]}
      />
      <Select
        defaultValue="lucy"
        style={{ width: 120 }}
        allowClear
        options={[{ value: 'lucy', label: 'Lucy' }]}
        placeholder="select it"
      />
    </Space>
  </>;
}
