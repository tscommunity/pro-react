import { SettingOutlined } from '@ant-design/icons';
import { Cascader, InputNumber, Select, Space } from 'antd';
import styles from './InputNumberDemo.module.scss';

export interface InputNumberDemoProps {
  prop?: string;
}

const { Option } = Select;

const selectBefore = (
  <Select defaultValue="add" style={{ width: 60 }}>
    <Option value="add">+</Option>
    <Option value="minus">-</Option>
  </Select>
);

const selectAfter = (
  <Select defaultValue="USD" style={{ width: 60 }}>
    <Option value="USD">$</Option>
    <Option value="EUR">€</Option>
    <Option value="GBP">£</Option>
    <Option value="CNY">¥</Option>
  </Select>
);

export function InputNumberDemo({ prop = '数字输入框示例' }: Readonly<InputNumberDemoProps>) {
  return <>
    <div className={styles.InputNumberDemo}>InputNumberDemo {prop}</div>

    <Space direction="vertical">
      <InputNumber size="large" addonBefore="+" addonAfter="$" defaultValue={100} />
      <InputNumber size="middle" addonBefore={selectBefore} addonAfter={selectAfter} defaultValue={100} />
      <InputNumber size="small" addonAfter={<SettingOutlined />} defaultValue={100} />
      <InputNumber
        addonBefore={<Cascader placeholder="cascader" style={{ width: 150 }} />}
        defaultValue={100}
      />
      <InputNumber
        addonBefore="+"
        addonAfter={<SettingOutlined />}
        defaultValue={100}
        disabled
        controls
      />
      <InputNumber
        prefix="¥"
        addonBefore="+"
        addonAfter={<SettingOutlined />}
        defaultValue={100}
        disabled
        controls
      />
    </Space>
  </>;
}
