import React from 'react';

import {InputNumberDemo} from '../InputNumberDemo';

describe('<InputNumberDemo />', () => {});
