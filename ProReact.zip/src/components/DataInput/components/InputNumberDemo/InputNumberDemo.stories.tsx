import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {InputNumberDemo} from './InputNumberDemo';

const meta: Meta<typeof InputNumberDemo> = {
  component: InputNumberDemo,
};

export default meta;

type Story = StoryObj<typeof InputNumberDemo>;

export const Basic: Story = {args: {}};
