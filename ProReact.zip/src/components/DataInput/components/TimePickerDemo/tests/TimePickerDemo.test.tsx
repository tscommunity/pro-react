import React from 'react';

import {TimePickerDemo} from '../TimePickerDemo';

describe('<TimePickerDemo />', () => {});
