import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TimePickerDemo} from './TimePickerDemo';

const meta: Meta<typeof TimePickerDemo> = {
  component: TimePickerDemo,
};

export default meta;

type Story = StoryObj<typeof TimePickerDemo>;

export const Basic: Story = {args: {}};
