import type { TimePickerProps } from 'antd';
import { Space, TimePicker } from 'antd';
import styles from './TimePickerDemo.module.scss';

export interface TimePickerDemoProps {
  prop?: string;
}

const onChange: TimePickerProps['onChange'] = (time, timeString) => {
  console.log(time, timeString);
};

export function TimePickerDemo({ prop = '时间选择器示例' }: Readonly<TimePickerDemoProps>) {
  return <>
    <div className={styles.TimePickerDemo}>TimePickerDemo {prop}</div>
    <Space wrap>
      <TimePicker onChange={onChange} />
      <TimePicker use12Hours format="h:mm:ss A" onChange={onChange} />
      <TimePicker use12Hours format="h:mm a" onChange={onChange} />
    </Space>
  </>;
}
