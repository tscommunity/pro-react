import React from 'react';

import {CascaderDemo} from '../CascaderDemo';

describe('<CascaderDemo />', () => {});
