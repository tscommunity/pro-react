import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {CascaderDemo} from './CascaderDemo';

const meta: Meta<typeof CascaderDemo> = {
  component: CascaderDemo,
};

export default meta;

type Story = StoryObj<typeof CascaderDemo>;

export const Basic: Story = {args: {}};
