import { Cascader } from "antd";
import type { CascaderProps } from "antd";
import styles from "./CascaderDemo.module.scss";

export interface CascaderDemoProps {
  prop?: string;
}

interface Option {
  value: string;
  label: string;
  children?: Option[];
}

const options: Option[] = [
  {
    value: "zhejiang",
    label: "Zhejiang",
    children: [
      {
        value: "hangzhou",
        label: "Hangzhou",
        children: [
          {
            value: "xihu",
            label: "West Lake",
          },
        ],
      },
    ],
  },
  {
    value: "jiangsu",
    label: "Jiangsu",
    children: [
      {
        value: "nanjing",
        label: "Nanjing",
        children: [
          {
            value: "zhonghuamen",
            label: "Zhong Hua Men",
          },
        ],
      },
    ],
  },
];

const onChange: CascaderProps<Option>["onChange"] = (value) => {
  console.log(value);
};

export function CascaderDemo({ prop = "级联选择示例" }: Readonly<CascaderDemoProps>) {
  return (
    <>
      <div className={styles.CascaderDemo}>CascaderDemo {prop}</div>

      <Cascader
        defaultValue={["zhejiang", "hangzhou", "xihu"]}
        options={options}
        onChange={onChange}
      />
    </>
  );
}
