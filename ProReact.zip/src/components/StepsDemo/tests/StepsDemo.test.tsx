import React from 'react';

import {StepsDemo} from '../StepsDemo';

describe('<StepsDemo />', () => {});
