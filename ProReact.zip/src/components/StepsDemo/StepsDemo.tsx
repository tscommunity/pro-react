import { Button, message, Space, Steps } from "antd";
import styles from "./StepsDemo.module.scss";
import { useState } from "react";

export interface StepsDemoProps {
  prop?: string;
}

const description = "This is a description.";

const steps = [
  {
    title: "First",
    content: "First-content",
  },
  {
    title: "Second",
    content: "Second-content",
  },
  {
    title: "Last",
    content: "Last-content",
  },
];

export function StepsDemo({ prop = "导航步骤条示例" }: Readonly<StepsDemoProps>) {
  const [current, setCurrent] = useState(0);

  const next = () => {
    setCurrent(current + 1);
  };

  const prev = () => {
    setCurrent(current - 1);
  };
  const items = steps.map((item) => ({ key: item.title, title: item.title }));

  return (
    <>
      <div className={styles.StepsDemo}>StepsDemo {prop}</div>
      <Space direction="vertical" size={60}>
        <Steps
          current={1}
          items={[
            {
              title: "Finished",
              description,
            },
            {
              title: "In Progress",
              description,
              subTitle: "Left 00:00:08",
            },
            {
              title: "Waiting",
              description,
            },
          ]}
        />

        <Steps current={current} items={items} />
        <div className="steps-content">{steps[current].content}</div>
        <div className="steps-action">
          {current < steps.length - 1 && (
            <Button type="primary" onClick={() => next()}>
              Next
            </Button>
          )}
          {current === steps.length - 1 && (
            <Button type="primary" onClick={() => message.success("Processing complete!")}>
              Done
            </Button>
          )}
          {current > 0 && (
            <Button style={{ margin: "0 8px" }} onClick={() => prev()}>
              Previous
            </Button>
          )}
        </div>
      </Space>
    </>
  );
}
