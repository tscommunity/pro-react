import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {StepsDemo} from './StepsDemo';

const meta: Meta<typeof StepsDemo> = {
  component: StepsDemo,
};

export default meta;

type Story = StoryObj<typeof StepsDemo>;

export const Basic: Story = {args: {}};
