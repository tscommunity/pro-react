import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {Common} from './Common';

const meta: Meta<typeof Common> = {
  component: Common,
};

export default meta;

type Story = StoryObj<typeof Common>;

export const Basic: Story = {args: {}};
