import React from 'react';

import {Common} from '../Common';

describe('<Common />', () => {});
