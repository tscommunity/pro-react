import { Outlet } from "react-router-dom";
import styles from "./Common.module.scss";

export interface CommonProps {
  prop?: string;
}

export function Common({ prop }: Readonly<CommonProps>) {
  return (
    <>
      <div className={styles.Common}>通用组件 {prop}</div>
      <Outlet />
    </>
  );
}
