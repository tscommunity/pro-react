import React from 'react';

import {MenuDemo} from '../MenuDemo';

describe('<MenuDemo />', () => {});
