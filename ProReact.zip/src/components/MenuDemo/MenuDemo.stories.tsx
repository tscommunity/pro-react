import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {MenuDemo} from './MenuDemo';

const meta: Meta<typeof MenuDemo> = {
  component: MenuDemo,
};

export default meta;

type Story = StoryObj<typeof MenuDemo>;

export const Basic: Story = {args: {}};
