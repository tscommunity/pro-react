import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {DropdownDemo} from './DropdownDemo';

const meta: Meta<typeof DropdownDemo> = {
  component: DropdownDemo,
};

export default meta;

type Story = StoryObj<typeof DropdownDemo>;

export const Basic: Story = {args: {}};
