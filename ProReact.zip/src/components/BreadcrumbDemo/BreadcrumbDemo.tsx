import { Breadcrumb } from "antd";
import { HomeOutlined, UserOutlined } from "@ant-design/icons";
import styles from "./BreadcrumbDemo.module.scss";

export interface BreadcrumbDemoProps {
  prop?: string;
}

export function BreadcrumbDemo({ prop = "面包屑导航示例" }: Readonly<BreadcrumbDemoProps>) {
  return (
    <>
      <div className={styles.BreadcrumbDemo}>BreadcrumbDemo {prop}</div>

      <Breadcrumb>
        <Breadcrumb.Item href="">
          <HomeOutlined />
        </Breadcrumb.Item>

        <Breadcrumb.Item href="">
          <UserOutlined />
          <span>Application List</span>
        </Breadcrumb.Item>

        <Breadcrumb.Item>Application</Breadcrumb.Item>
      </Breadcrumb>
    </>
  );
}
