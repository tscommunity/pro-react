import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {BreadcrumbDemo} from './BreadcrumbDemo';

const meta: Meta<typeof BreadcrumbDemo> = {
  component: BreadcrumbDemo,
};

export default meta;

type Story = StoryObj<typeof BreadcrumbDemo>;

export const Basic: Story = {args: {}};
