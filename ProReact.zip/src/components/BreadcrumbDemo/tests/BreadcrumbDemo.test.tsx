import React from 'react';

import {BreadcrumbDemo} from '../BreadcrumbDemo';

describe('<BreadcrumbDemo />', () => {});
