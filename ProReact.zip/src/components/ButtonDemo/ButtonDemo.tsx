import { Button, Flex } from "antd";
export interface ButtonDemoProps {
  prop?: string;
}

export function ButtonDemo({ prop = "default value" }: Readonly<ButtonDemoProps>) {
  return (
    <Flex vertical gap="small">
      <div>按钮组件示例</div>
      <Flex gap="small" wrap>
        <Button color="default" type="primary">
          Dashed
        </Button>
        <Button color="default" type="dashed">
          Dashed
        </Button>
        <Button color="default" type="text">
          Text
        </Button>
        <Button color="default" type="link">
          Link
        </Button>
      </Flex>
    </Flex>
  );
}
