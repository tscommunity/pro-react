import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {ButtonDemo} from './ButtonDemo';

const meta: Meta<typeof ButtonDemo> = {
  component: ButtonDemo,
};

export default meta;

type Story = StoryObj<typeof ButtonDemo>;

export const Basic: Story = {args: {}};
