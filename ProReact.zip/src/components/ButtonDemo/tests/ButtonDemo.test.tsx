import React from 'react';

import {ButtonDemo} from '../ButtonDemo';

describe('<ButtonDemo />', () => {});
