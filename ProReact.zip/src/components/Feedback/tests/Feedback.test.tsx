import React from 'react';

import {Feedback} from '../Feedback';

describe('<Feedback />', () => {});
