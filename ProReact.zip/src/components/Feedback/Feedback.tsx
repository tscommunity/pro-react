import styles from './Feedback.module.scss';
import { Outlet } from 'react-router-dom';

export interface FeedbackProps {
  prop?: string;
}

export function Feedback({ prop = '反馈示例' }: Readonly<FeedbackProps>) {
  return <>
    <div className={styles.Feedback}>Feedback {prop}</div>

    <Outlet />
  </>;
}
