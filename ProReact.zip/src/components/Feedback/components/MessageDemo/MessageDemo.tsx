import { Button, message, Space } from 'antd';
import styles from './MessageDemo.module.scss';

export interface MessageDemoProps {
  prop?: string;
}

export function MessageDemo({ prop = '全局提示示例' }: Readonly<MessageDemoProps>) {
  const [messageApi, contextHolder] = message.useMessage();

  const success = () => {
    messageApi.open({
      type: 'success',
      content: 'This is a success message',
    });
  };

  const error = () => {
    messageApi.open({
      type: 'error',
      content: 'This is an error message',
    });
  };

  const warning = () => {
    messageApi.open({
      type: 'warning',
      content: 'This is a warning message',
    });
  };


  return <>
    <div className={styles.MessageDemo}>MessageDemo {prop}</div>

    {contextHolder}
    <Space>
      <Button onClick={success}>Success</Button>
      <Button onClick={error}>Error</Button>
      <Button onClick={warning}>Warning</Button>
    </Space>
  </>;
}
