import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {MessageDemo} from './MessageDemo';

const meta: Meta<typeof MessageDemo> = {
  component: MessageDemo,
};

export default meta;

type Story = StoryObj<typeof MessageDemo>;

export const Basic: Story = {args: {}};
