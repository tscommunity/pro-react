import React from 'react';

import {MessageDemo} from '../MessageDemo';

describe('<MessageDemo />', () => {});
