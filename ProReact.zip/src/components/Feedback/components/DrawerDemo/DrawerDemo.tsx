import { useState } from 'react';
import type { DrawerProps, RadioChangeEvent } from 'antd';
import { Button, Drawer, Radio, Space } from 'antd';
import styles from './DrawerDemo.module.scss';

export interface DrawerDemoProps {
  prop?: string;
}

export function DrawerDemo({ prop = '抽屉组件示例' }: Readonly<DrawerDemoProps>) {
  const [open, setOpen] = useState(false);
  const [placement, setPlacement] = useState<DrawerProps['placement']>('left');

  const showDrawer = () => {
    setOpen(true);
  };

  const onClose = () => {
    setOpen(false);
  };

  const onChange = (e: RadioChangeEvent) => {
    setPlacement(e.target.value);
  };

  return <>
    <div className={styles.DrawerDemo}>DrawerDemo {prop}</div>

    <Space>
      <Radio.Group value={placement} onChange={onChange}>
        <Radio value="top">top</Radio>
        <Radio value="right">right</Radio>
        <Radio value="bottom">bottom</Radio>
        <Radio value="left">left</Radio>
      </Radio.Group>
      <Button type="primary" onClick={showDrawer}>
        Open
      </Button>
    </Space>
    <Drawer
      title="Basic Drawer"
      placement={placement}
      closable={false}
      onClose={onClose}
      open={open}
      key={placement}
    >
      <p>Some contents...</p>
      <p>Some contents...</p>
      <p>Some contents...</p>
    </Drawer>
  </>;
}
