import React from 'react';

import {DrawerDemo} from '../DrawerDemo';

describe('<DrawerDemo />', () => {});
