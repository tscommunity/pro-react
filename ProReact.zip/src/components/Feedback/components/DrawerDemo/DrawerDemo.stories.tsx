import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {DrawerDemo} from './DrawerDemo';

const meta: Meta<typeof DrawerDemo> = {
  component: DrawerDemo,
};

export default meta;

type Story = StoryObj<typeof DrawerDemo>;

export const Basic: Story = {args: {}};
