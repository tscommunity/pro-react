import React from 'react';

import {ModalDemo} from '../ModalDemo';

describe('<ModalDemo />', () => {});
