import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {ModalDemo} from './ModalDemo';

const meta: Meta<typeof ModalDemo> = {
  component: ModalDemo,
};

export default meta;

type Story = StoryObj<typeof ModalDemo>;

export const Basic: Story = {args: {}};
