import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {Feedback} from './Feedback';

const meta: Meta<typeof Feedback> = {
  component: Feedback,
};

export default meta;

type Story = StoryObj<typeof Feedback>;

export const Basic: Story = {args: {}};
