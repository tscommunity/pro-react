import { Outlet } from 'react-router-dom';
import styles from './DataPresentation.module.scss';

export interface DataPresentationProps {
  prop?: string;
}

export function DataPresentation({ prop = '数据展示示例' }: Readonly<DataPresentationProps>) {
  return <>
    <div className={styles.DataPresentation}>DataPresentation {prop}</div>

    <Outlet />
  </>;
}
