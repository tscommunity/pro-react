import React from 'react';

import {DataPresentation} from '../DataPresentation';

describe('<DataPresentation />', () => {});
