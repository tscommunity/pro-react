import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {ImageDemo} from './ImageDemo';

const meta: Meta<typeof ImageDemo> = {
  component: ImageDemo,
};

export default meta;

type Story = StoryObj<typeof ImageDemo>;

export const Basic: Story = {args: {}};
