import React from 'react';

import {ImageDemo} from '../ImageDemo';

describe('<ImageDemo />', () => {});
