import { Image, Space } from 'antd';
import styles from './ImageDemo.module.scss';

export interface ImageDemoProps {
  prop?: string;
}

export function ImageDemo({ prop = '图片组件示例' }: Readonly<ImageDemoProps>) {
  return <>
    <div className={styles.ImageDemo}>ImageDemo {prop}</div>;

    <Space direction='vertical'>
      <Image
        width={200}
        src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png?x-oss-process=image/blur,r_50,s_50/quality,q_1/resize,m_mfit,h_200,w_200"
        preview={{

          src: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
        }}
      />

      <Image.PreviewGroup
        items={[
          'https://gw.alipayobjects.com/zos/antfincdn/LlvErxo8H9/photo-1503185912284-5271ff81b9a8.webp',
          'https://gw.alipayobjects.com/zos/antfincdn/cV16ZqzMjW/photo-1473091540282-9b846e7965e3.webp',
          'https://gw.alipayobjects.com/zos/antfincdn/x43I27A55%26/photo-1438109491414-7198515b166b.webp',
        ]}
      >
        <Image
          width={200}
          src="https://gw.alipayobjects.com/zos/antfincdn/LlvErxo8H9/photo-1503185912284-5271ff81b9a8.webp"
        />
      </Image.PreviewGroup>
    </Space>
  </>
}
