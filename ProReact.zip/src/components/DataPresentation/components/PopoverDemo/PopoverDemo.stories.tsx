import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {PopoverDemo} from './PopoverDemo';

const meta: Meta<typeof PopoverDemo> = {
  component: PopoverDemo,
};

export default meta;

type Story = StoryObj<typeof PopoverDemo>;

export const Basic: Story = {args: {}};
