import React from 'react';

import {PopoverDemo} from '../PopoverDemo';

describe('<PopoverDemo />', () => {});
