import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {SegmentedDemo} from './SegmentedDemo';

const meta: Meta<typeof SegmentedDemo> = {
  component: SegmentedDemo,
};

export default meta;

type Story = StoryObj<typeof SegmentedDemo>;

export const Basic: Story = {args: {}};
