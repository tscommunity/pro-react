import React from 'react';

import {SegmentedDemo} from '../SegmentedDemo';

describe('<SegmentedDemo />', () => {});
