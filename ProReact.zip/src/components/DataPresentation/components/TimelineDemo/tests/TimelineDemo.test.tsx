import React from 'react';

import {TimelineDemo} from '../TimelineDemo';

describe('<TimelineDemo />', () => {});
