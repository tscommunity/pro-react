import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TimelineDemo} from './TimelineDemo';

const meta: Meta<typeof TimelineDemo> = {
  component: TimelineDemo,
};

export default meta;

type Story = StoryObj<typeof TimelineDemo>;

export const Basic: Story = {args: {}};
