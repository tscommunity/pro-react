import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {StatisticDemo} from './StatisticDemo';

const meta: Meta<typeof StatisticDemo> = {
  component: StatisticDemo,
};

export default meta;

type Story = StoryObj<typeof StatisticDemo>;

export const Basic: Story = {args: {}};
