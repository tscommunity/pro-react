import React from 'react';

import {StatisticDemo} from '../StatisticDemo';

describe('<StatisticDemo />', () => {});
