import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableRowColumnMergedDemo} from './TableRowColumnMergedDemo';

const meta: Meta<typeof TableRowColumnMergedDemo> = {
  component: TableRowColumnMergedDemo,
};

export default meta;

type Story = StoryObj<typeof TableRowColumnMergedDemo>;

export const Basic: Story = {args: {}};
