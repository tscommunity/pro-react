import React from 'react';

import {TableRowColumnMergedDemo} from '../TableRowColumnMergedDemo';

describe('<TableRowColumnMergedDemo />', () => {});
