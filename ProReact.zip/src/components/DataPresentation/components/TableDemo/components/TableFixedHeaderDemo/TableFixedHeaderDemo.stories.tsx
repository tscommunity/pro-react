import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableFixedHeaderDemo} from './TableFixedHeaderDemo';

const meta: Meta<typeof TableFixedHeaderDemo> = {
  component: TableFixedHeaderDemo,
};

export default meta;

type Story = StoryObj<typeof TableFixedHeaderDemo>;

export const Basic: Story = {args: {}};
