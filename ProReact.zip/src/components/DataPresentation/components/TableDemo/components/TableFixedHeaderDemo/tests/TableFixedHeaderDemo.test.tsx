import React from 'react';

import {TableFixedHeaderDemo} from '../TableFixedHeaderDemo';

describe('<TableFixedHeaderDemo />', () => {});
