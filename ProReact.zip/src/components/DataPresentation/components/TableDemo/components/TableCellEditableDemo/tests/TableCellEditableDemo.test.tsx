import React from 'react';

import {TableCellEditableDemo} from '../TableCellEditableDemo';

describe('<TableCellEditableDemo />', () => {});
