import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableCellEditableDemo} from './TableCellEditableDemo';

const meta: Meta<typeof TableCellEditableDemo> = {
  component: TableCellEditableDemo,
};

export default meta;

type Story = StoryObj<typeof TableCellEditableDemo>;

export const Basic: Story = {args: {}};
