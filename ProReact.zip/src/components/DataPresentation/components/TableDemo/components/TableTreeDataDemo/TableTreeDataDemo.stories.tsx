import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableTreeDataDemo} from './TableTreeDataDemo';

const meta: Meta<typeof TableTreeDataDemo> = {
  component: TableTreeDataDemo,
};

export default meta;

type Story = StoryObj<typeof TableTreeDataDemo>;

export const Basic: Story = {args: {}};
