import React from 'react';

import {TableExpandableDemo} from '../TableExpandableDemo';

describe('<TableExpandableDemo />', () => {});
