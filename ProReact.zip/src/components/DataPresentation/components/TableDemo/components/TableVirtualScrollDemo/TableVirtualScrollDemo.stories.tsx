import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableVirtualScrollDemo} from './TableVirtualScrollDemo';

const meta: Meta<typeof TableVirtualScrollDemo> = {
  component: TableVirtualScrollDemo,
};

export default meta;

type Story = StoryObj<typeof TableVirtualScrollDemo>;

export const Basic: Story = {args: {}};
