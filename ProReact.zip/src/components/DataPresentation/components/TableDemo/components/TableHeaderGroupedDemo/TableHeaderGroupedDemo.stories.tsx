import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableHeaderGroupedDemo} from './TableHeaderGroupedDemo';

const meta: Meta<typeof TableHeaderGroupedDemo> = {
  component: TableHeaderGroupedDemo,
};

export default meta;

type Story = StoryObj<typeof TableHeaderGroupedDemo>;

export const Basic: Story = {args: {}};
