import React from 'react';

import {TableHeaderGroupedDemo} from '../TableHeaderGroupedDemo';

describe('<TableHeaderGroupedDemo />', () => {});
