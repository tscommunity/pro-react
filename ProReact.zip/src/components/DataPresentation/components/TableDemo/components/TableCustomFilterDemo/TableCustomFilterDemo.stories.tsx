import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableCustomFilterDemo} from './TableCustomFilterDemo';

const meta: Meta<typeof TableCustomFilterDemo> = {
  component: TableCustomFilterDemo,
};

export default meta;

type Story = StoryObj<typeof TableCustomFilterDemo>;

export const Basic: Story = {args: {}};
