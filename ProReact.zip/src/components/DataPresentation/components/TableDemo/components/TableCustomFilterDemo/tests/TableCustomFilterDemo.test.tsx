import React from 'react';

import {TableCustomFilterDemo} from '../TableCustomFilterDemo';

describe('<TableCustomFilterDemo />', () => {});
