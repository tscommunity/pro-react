import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableSummaryDemo} from './TableSummaryDemo';

const meta: Meta<typeof TableSummaryDemo> = {
  component: TableSummaryDemo,
};

export default meta;

type Story = StoryObj<typeof TableSummaryDemo>;

export const Basic: Story = {args: {}};
