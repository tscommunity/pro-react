import React from 'react';

import {TableSummaryDemo} from '../TableSummaryDemo';

describe('<TableSummaryDemo />', () => {});
