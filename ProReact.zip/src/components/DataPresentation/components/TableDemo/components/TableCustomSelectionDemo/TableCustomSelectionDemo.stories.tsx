import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableCustomSelectionDemo} from './TableCustomSelectionDemo';

const meta: Meta<typeof TableCustomSelectionDemo> = {
  component: TableCustomSelectionDemo,
};

export default meta;

type Story = StoryObj<typeof TableCustomSelectionDemo>;

export const Basic: Story = {args: {}};
