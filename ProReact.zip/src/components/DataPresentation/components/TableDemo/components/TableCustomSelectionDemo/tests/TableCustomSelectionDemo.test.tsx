import React from 'react';

import {TableCustomSelectionDemo} from '../TableCustomSelectionDemo';

describe('<TableCustomSelectionDemo />', () => {});
