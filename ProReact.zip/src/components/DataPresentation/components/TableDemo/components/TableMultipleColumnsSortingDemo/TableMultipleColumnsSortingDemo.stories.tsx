import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableMultipleColumnsSortingDemo} from './TableMultipleColumnsSortingDemo';

const meta: Meta<typeof TableMultipleColumnsSortingDemo> = {
  component: TableMultipleColumnsSortingDemo,
};

export default meta;

type Story = StoryObj<typeof TableMultipleColumnsSortingDemo>;

export const Basic: Story = {args: {}};
