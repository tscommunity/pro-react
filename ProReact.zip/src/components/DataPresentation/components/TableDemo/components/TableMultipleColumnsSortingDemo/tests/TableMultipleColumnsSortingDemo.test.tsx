import React from 'react';

import {TableMultipleColumnsSortingDemo} from '../TableMultipleColumnsSortingDemo';

describe('<TableMultipleColumnsSortingDemo />', () => {});
