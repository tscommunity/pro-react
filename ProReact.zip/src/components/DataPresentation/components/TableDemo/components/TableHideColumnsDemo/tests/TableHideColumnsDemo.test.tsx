import React from 'react';

import {TableHideColumnsDemo} from '../TableHideColumnsDemo';

describe('<TableHideColumnsDemo />', () => {});
