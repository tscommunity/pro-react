import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableHideColumnsDemo} from './TableHideColumnsDemo';

const meta: Meta<typeof TableHideColumnsDemo> = {
  component: TableHideColumnsDemo,
};

export default meta;

type Story = StoryObj<typeof TableHideColumnsDemo>;

export const Basic: Story = {args: {}};
