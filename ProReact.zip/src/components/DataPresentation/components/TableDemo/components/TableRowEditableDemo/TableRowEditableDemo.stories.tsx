import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableRowEditableDemo} from './TableRowEditableDemo';

const meta: Meta<typeof TableRowEditableDemo> = {
  component: TableRowEditableDemo,
};

export default meta;

type Story = StoryObj<typeof TableRowEditableDemo>;

export const Basic: Story = {args: {}};
