import React from 'react';

import {TableRowEditableDemo} from '../TableRowEditableDemo';

describe('<TableRowEditableDemo />', () => {});
