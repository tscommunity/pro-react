import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableTreeFilterDemo} from './TableTreeFilterDemo';

const meta: Meta<typeof TableTreeFilterDemo> = {
  component: TableTreeFilterDemo,
};

export default meta;

type Story = StoryObj<typeof TableTreeFilterDemo>;

export const Basic: Story = {args: {}};
