import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableSelectableDemo} from './TableSelectableDemo';

const meta: Meta<typeof TableSelectableDemo> = {
  component: TableSelectableDemo,
};

export default meta;

type Story = StoryObj<typeof TableSelectableDemo>;

export const Basic: Story = {args: {}};
