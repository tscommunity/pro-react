import React from 'react';

import {TableSelectableDemo} from '../TableSelectableDemo';

describe('<TableSelectableDemo />', () => {});
