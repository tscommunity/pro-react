import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TableDemo} from './TableDemo';

const meta: Meta<typeof TableDemo> = {
  component: TableDemo,
};

export default meta;

type Story = StoryObj<typeof TableDemo>;

export const Basic: Story = {args: {}};
