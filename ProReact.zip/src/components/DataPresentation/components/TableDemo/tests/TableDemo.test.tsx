import React from 'react';

import {TableDemo} from '../TableDemo';

describe('<TableDemo />', () => {});
