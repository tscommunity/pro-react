import { Space, Table, Tag } from 'antd';
import type { TableProps } from 'antd';
import type { TableColumnsType } from 'antd';
import styles from './TableDemo.module.scss';
import { TableCellEditableDemo, TableCustomFilterDemo, TableCustomSelectionDemo, TableExpandableDemo, TableFixedHeaderDemo, TableHeaderGroupedDemo, TableHideColumnsDemo, TableMultipleColumnsSortingDemo, TableRowColumnMergedDemo, TableRowEditableDemo, TableSelectableDemo, TableSummaryDemo, TableTreeDataDemo, TableTreeFilterDemo, TableVirtualScrollDemo } from './components';

export interface TableDemoProps {
  prop?: string;
}

interface DataType {
  key: string;
  name: string;
  age: number;
  address: string;
  tags?: string[];
}

const columns: TableProps<DataType>['columns'] = [
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    render: (text) => <a>{text}</a>,
  },
  {
    title: 'Age',
    dataIndex: 'age',
    key: 'age',
  },
  {
    title: 'Address',
    dataIndex: 'address',
    key: 'address',
  },
  {
    title: 'Tags',
    key: 'tags',
    dataIndex: 'tags',
    render: (_, { tags }) => (
      <>
        {tags.map((tag) => {
          let color = tag.length > 5 ? 'geekblue' : 'green';
          if (tag === 'loser') {
            color = 'volcano';
          }
          return (
            <Tag color={color} key={tag}>
              {tag.toUpperCase()}
            </Tag>
          );
        })}
      </>
    ),
  },
  {
    title: 'Action',
    key: 'action',
    render: (_, record) => (
      <Space size="middle">
        <a>Invite {record.name}</a>
        <a>Delete</a>
      </Space>
    ),
  },
];

const data: DataType[] = [
  {
    key: '1',
    name: 'John Brown',
    age: 32,
    address: 'New York No. 1 Lake Park',
    tags: ['nice', 'developer'],
  },
  {
    key: '2',
    name: 'Jim Green',
    age: 42,
    address: 'London No. 1 Lake Park',
    tags: ['loser'],
  },
  {
    key: '3',
    name: 'Joe Black',
    age: 32,
    address: 'Sydney No. 1 Lake Park',
    tags: ['cool', 'teacher'],
  },
];

const columns2: TableColumnsType<DataType> = [
  {
    title: 'Name',
    dataIndex: 'name',
    width: 150,
  },
  {
    title: 'Age',
    dataIndex: 'age',
    width: 150,
  },
  {
    title: 'Address',
    dataIndex: 'address',
  },
];

const dataSource = Array.from({ length: 100 }).map<DataType>((_, i) => ({
  key: `${i}`,
  name: `Edward King ${i}`,
  age: 32,
  address: `London, Park Lane no. ${i}`,
}));

export function TableDemo({ prop = '表格组件示例' }: Readonly<TableDemoProps>) {

  return <>
    <div className={styles.TableDemo}>TableDemo {prop}</div>

    <Space direction='vertical' size="large">

      <Table<DataType> columns={columns} dataSource={data} />

      <Table<DataType>
        className={styles.customTable}
        columns={columns2}
        dataSource={dataSource}
        pagination={{ pageSize: 50 }}
        scroll={{ y: 55 * 5 }}
      />

      <div>表格行/列合并示例</div>
      <TableRowColumnMergedDemo />

      <div>表格表头分组示例</div>
      <TableHeaderGroupedDemo />

      <TableCellEditableDemo />

      <TableRowEditableDemo />

      <TableSummaryDemo />

      <TableVirtualScrollDemo />

      <TableHideColumnsDemo />

      <TableFixedHeaderDemo />

      <TableTreeDataDemo />

      <TableExpandableDemo />

      <TableCustomFilterDemo />

      <TableMultipleColumnsSortingDemo />

      <TableTreeFilterDemo />

      <TableCustomSelectionDemo />

      <TableSelectableDemo />
    </Space>
  </>;
}
