import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TooltipDemo} from './TooltipDemo';

const meta: Meta<typeof TooltipDemo> = {
  component: TooltipDemo,
};

export default meta;

type Story = StoryObj<typeof TooltipDemo>;

export const Basic: Story = {args: {}};
