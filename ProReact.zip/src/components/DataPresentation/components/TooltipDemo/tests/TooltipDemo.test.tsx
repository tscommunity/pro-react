import React from 'react';

import {TooltipDemo} from '../TooltipDemo';

describe('<TooltipDemo />', () => {});
