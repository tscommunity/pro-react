import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {CalendarDemo} from './CalendarDemo';

const meta: Meta<typeof CalendarDemo> = {
  component: CalendarDemo,
};

export default meta;

type Story = StoryObj<typeof CalendarDemo>;

export const Basic: Story = {args: {}};
