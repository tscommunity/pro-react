import { Calendar } from 'antd';
import styles from './CalendarDemo.module.scss';

export interface CalendarDemoProps {
  prop?: string;
}

export function CalendarDemo({ prop = '日历组件示例' }: Readonly<CalendarDemoProps>) {
  return <>
    <div className={styles.CalendarDemo}>CalendarDemo {prop}</div>
    <Calendar />
  </>;
}
