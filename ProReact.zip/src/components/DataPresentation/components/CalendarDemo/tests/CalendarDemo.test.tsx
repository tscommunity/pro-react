import React from 'react';

import {CalendarDemo} from '../CalendarDemo';

describe('<CalendarDemo />', () => {});
