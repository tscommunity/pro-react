import React from 'react';

import {TourDemo} from '../TourDemo';

describe('<TourDemo />', () => {});
