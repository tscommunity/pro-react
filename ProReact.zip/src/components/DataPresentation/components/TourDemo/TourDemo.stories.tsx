import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TourDemo} from './TourDemo';

const meta: Meta<typeof TourDemo> = {
  component: TourDemo,
};

export default meta;

type Story = StoryObj<typeof TourDemo>;

export const Basic: Story = {args: {}};
