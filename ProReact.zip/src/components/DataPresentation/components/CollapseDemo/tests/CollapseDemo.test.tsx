import React from 'react';

import {CollapseDemo} from '../CollapseDemo';

describe('<CollapseDemo />', () => {});
