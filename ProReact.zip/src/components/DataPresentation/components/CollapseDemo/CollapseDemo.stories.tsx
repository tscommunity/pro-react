import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {CollapseDemo} from './CollapseDemo';

const meta: Meta<typeof CollapseDemo> = {
  component: CollapseDemo,
};

export default meta;

type Story = StoryObj<typeof CollapseDemo>;

export const Basic: Story = {args: {}};
