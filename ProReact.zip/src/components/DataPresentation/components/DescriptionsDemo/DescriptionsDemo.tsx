import { Descriptions } from 'antd';
import type { DescriptionsProps } from 'antd';
import styles from './DescriptionsDemo.module.scss';

export interface DescriptionsDemoProps {
  prop?: string;
}

const items: DescriptionsProps['items'] = [
  {
    key: '1',
    label: 'UserName',
    children: 'Zhou Maomao',
  },
  {
    key: '2',
    label: 'Telephone',
    children: '1810000000',
  },
  {
    key: '3',
    label: 'Live',
    children: 'Hangzhou, Zhejiang',
  },
  {
    key: '4',
    label: 'Remark',
    children: 'empty',
  },
  {
    key: '5',
    label: 'Address',
    children: 'No. 18, Wantang Road, Xihu District, Hangzhou, Zhejiang, China',
  },
];

export function DescriptionsDemo({ prop = '描述列表组件示例' }: Readonly<DescriptionsDemoProps>) {
  return <>
    <div className={styles.DescriptionsDemo}>DescriptionsDemo {prop}</div>

    <Descriptions title="User Info" items={items} />
  </>;
}
