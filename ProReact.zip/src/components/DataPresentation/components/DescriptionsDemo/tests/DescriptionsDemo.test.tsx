import React from 'react';

import {DescriptionsDemo} from '../DescriptionsDemo';

describe('<DescriptionsDemo />', () => {});
