import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {DescriptionsDemo} from './DescriptionsDemo';

const meta: Meta<typeof DescriptionsDemo> = {
  component: DescriptionsDemo,
};

export default meta;

type Story = StoryObj<typeof DescriptionsDemo>;

export const Basic: Story = {args: {}};
