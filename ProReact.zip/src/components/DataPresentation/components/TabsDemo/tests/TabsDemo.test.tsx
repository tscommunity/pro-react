import React from 'react';

import {TabsDemo} from '../TabsDemo';

describe('<TabsDemo />', () => {});
