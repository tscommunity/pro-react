import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TabsDemo} from './TabsDemo';

const meta: Meta<typeof TabsDemo> = {
  component: TabsDemo,
};

export default meta;

type Story = StoryObj<typeof TabsDemo>;

export const Basic: Story = {args: {}};
