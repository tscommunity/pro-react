import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {ListDemo} from './ListDemo';

const meta: Meta<typeof ListDemo> = {
  component: ListDemo,
};

export default meta;

type Story = StoryObj<typeof ListDemo>;

export const Basic: Story = {args: {}};
