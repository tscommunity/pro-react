import { Divider, List, Typography } from 'antd';
import styles from './ListDemo.module.scss';

const data = [
  'Racing car sprays burning fuel into crowd.',
  'Japanese princess to wed commoner.',
  'Australian walks 100km after outback crash.',
  'Man charged over missing wedding girl.',
  'Los Angeles battles huge wildfires.',
];

export interface ListDemoProps {
  prop?: string;
}

export function ListDemo({ prop = '列表组件示例' }: Readonly<ListDemoProps>) {
  return <>
    <div className={styles.ListDemo}>ListDemo {prop}</div>

    <Divider orientation="left">Default Size</Divider>
    <List
      header={<div>Header</div>}
      footer={<div>Footer</div>}
      bordered
      dataSource={data}
      renderItem={(item) => (
        <List.Item>
          <Typography.Text mark>[ITEM]</Typography.Text> {item}
        </List.Item>
      )}
    />
  </>;
}
