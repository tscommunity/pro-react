import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TagDemo} from './TagDemo';

const meta: Meta<typeof TagDemo> = {
  component: TagDemo,
};

export default meta;

type Story = StoryObj<typeof TagDemo>;

export const Basic: Story = {args: {}};
