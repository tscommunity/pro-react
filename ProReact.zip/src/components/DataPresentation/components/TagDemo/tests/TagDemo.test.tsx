import React from 'react';

import {TagDemo} from '../TagDemo';

describe('<TagDemo />', () => {});
