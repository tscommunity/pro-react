import { Card, Space } from 'antd';
import styles from './CardDemo.module.scss';

export interface CardDemoProps {
  prop?: string;
}

export function CardDemo({ prop = '卡片组件示例' }: Readonly<CardDemoProps>) {
  return <>
    <div className={styles.CardDemo}>CardDemo {prop}</div>

    <Space direction="vertical" size={16}>
      <Card title="Default size card" extra={<a href="#">More</a>} style={{ width: 300 }}>
        <p>Card content</p>
        <p>Card content</p>
        <p>Card content</p>
      </Card>
      <Card size="small" title="Small size card" extra={<a href="#">More</a>} style={{ width: 300 }}>
        <p>Card content</p>
        <p>Card content</p>
        <p>Card content</p>
      </Card>
    </Space>
  </>;
}
