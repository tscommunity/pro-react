import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {CardDemo} from './CardDemo';

const meta: Meta<typeof CardDemo> = {
  component: CardDemo,
};

export default meta;

type Story = StoryObj<typeof CardDemo>;

export const Basic: Story = {args: {}};
