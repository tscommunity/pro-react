import React from 'react';

import {CardDemo} from '../CardDemo';

describe('<CardDemo />', () => {});
