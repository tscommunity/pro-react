import { UserOutlined } from '@ant-design/icons';
import { Avatar, Space } from 'antd';
import styles from './AvatarDemo.module.scss';

export interface AvatarDemoProps {
  prop?: string;
}

const url = 'https://gw.alipayobjects.com/zos/rmsportal/KDpgvguMpGfqaHPjicRK.svg';


export function AvatarDemo({ prop = '头像组件示例' }: Readonly<AvatarDemoProps>) {
  return <>
    <div className={styles.AvatarDemo}>AvatarDemo {prop}</div>

    <Space size={16} wrap>
      <Avatar icon={<UserOutlined />} />
      <Avatar>U</Avatar>
      <Avatar size={40}>USER</Avatar>
      <Avatar size="large" src={url} />
      <Avatar size="small" src={<img src={url} alt="avatar" />} />
      <Avatar style={{ backgroundColor: '#fde3cf', color: '#f56a00' }}>U</Avatar>
      <Avatar style={{ backgroundColor: '#87d068' }} icon={<UserOutlined />} />
    </Space>
  </>;
}
