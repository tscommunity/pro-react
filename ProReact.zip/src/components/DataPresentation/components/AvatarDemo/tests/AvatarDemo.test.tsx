import React from 'react';

import {AvatarDemo} from '../AvatarDemo';

describe('<AvatarDemo />', () => {});
