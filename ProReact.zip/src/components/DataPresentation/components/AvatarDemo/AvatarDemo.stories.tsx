import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {AvatarDemo} from './AvatarDemo';

const meta: Meta<typeof AvatarDemo> = {
  component: AvatarDemo,
};

export default meta;

type Story = StoryObj<typeof AvatarDemo>;

export const Basic: Story = {args: {}};
