import React from 'react';

import {TreeDemo} from '../TreeDemo';

describe('<TreeDemo />', () => {});
