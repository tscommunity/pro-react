import React from 'react';

import {TreeDataAsyncLoadDemo} from '../TreeDataAsyncLoadDemo';

describe('<TreeDataAsyncLoadDemo />', () => {});
