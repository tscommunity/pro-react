import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TreeDataAsyncLoadDemo} from './TreeDataAsyncLoadDemo';

const meta: Meta<typeof TreeDataAsyncLoadDemo> = {
  component: TreeDataAsyncLoadDemo,
};

export default meta;

type Story = StoryObj<typeof TreeDataAsyncLoadDemo>;

export const Basic: Story = {args: {}};
