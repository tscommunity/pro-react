import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TreeSearchableDemo} from './TreeSearchableDemo';

const meta: Meta<typeof TreeSearchableDemo> = {
  component: TreeSearchableDemo,
};

export default meta;

type Story = StoryObj<typeof TreeSearchableDemo>;

export const Basic: Story = {args: {}};
