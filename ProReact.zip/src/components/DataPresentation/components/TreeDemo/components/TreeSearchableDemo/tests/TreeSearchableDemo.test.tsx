import React from 'react';

import {TreeSearchableDemo} from '../TreeSearchableDemo';

describe('<TreeSearchableDemo />', () => {});
