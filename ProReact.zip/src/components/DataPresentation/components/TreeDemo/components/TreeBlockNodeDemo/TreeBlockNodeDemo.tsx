import { Tree } from 'antd';
import type { TreeDataNode } from 'antd';

import styles from './TreeBlockNodeDemo.module.scss';

export interface TreeBlockNodeDemoProps {
  prop?: string;
}

const treeData: TreeDataNode[] = [
  {
    title: 'parent',
    key: '0',
    children: [
      {
        title: 'child 1',
        key: '0-0',
        disabled: true,
      },
      {
        title: 'child 2',
        key: '0-1',
        disableCheckbox: true,
      },
    ],
  },
];

export function TreeBlockNodeDemo({ prop = '树节点占据整行示例' }: Readonly<TreeBlockNodeDemoProps>) {
  return <>
    <div className={styles.TreeBlockNodeDemo}>TreeBlockNodeDemo {prop}</div>

    <Tree checkable defaultSelectedKeys={['0-1']} defaultExpandAll treeData={treeData} blockNode />
  </>;
}
