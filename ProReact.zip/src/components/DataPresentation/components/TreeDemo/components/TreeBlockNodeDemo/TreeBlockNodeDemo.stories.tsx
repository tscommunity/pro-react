import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TreeBlockNodeDemo} from './TreeBlockNodeDemo';

const meta: Meta<typeof TreeBlockNodeDemo> = {
  component: TreeBlockNodeDemo,
};

export default meta;

type Story = StoryObj<typeof TreeBlockNodeDemo>;

export const Basic: Story = {args: {}};
