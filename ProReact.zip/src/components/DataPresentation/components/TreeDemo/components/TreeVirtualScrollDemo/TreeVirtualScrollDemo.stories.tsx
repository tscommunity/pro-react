import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TreeVirtualScrollDemo} from './TreeVirtualScrollDemo';

const meta: Meta<typeof TreeVirtualScrollDemo> = {
  component: TreeVirtualScrollDemo,
};

export default meta;

type Story = StoryObj<typeof TreeVirtualScrollDemo>;

export const Basic: Story = {args: {}};
