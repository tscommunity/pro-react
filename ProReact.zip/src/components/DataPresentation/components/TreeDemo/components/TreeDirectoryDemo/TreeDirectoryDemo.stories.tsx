import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TreeDirectoryDemo} from './TreeDirectoryDemo';

const meta: Meta<typeof TreeDirectoryDemo> = {
  component: TreeDirectoryDemo,
};

export default meta;

type Story = StoryObj<typeof TreeDirectoryDemo>;

export const Basic: Story = {args: {}};
