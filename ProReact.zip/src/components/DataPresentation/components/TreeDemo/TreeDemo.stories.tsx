import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {TreeDemo} from './TreeDemo';

const meta: Meta<typeof TreeDemo> = {
  component: TreeDemo,
};

export default meta;

type Story = StoryObj<typeof TreeDemo>;

export const Basic: Story = {args: {}};
