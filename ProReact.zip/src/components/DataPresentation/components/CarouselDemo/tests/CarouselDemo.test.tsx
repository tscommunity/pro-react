import React from 'react';

import {CarouselDemo} from '../CarouselDemo';

describe('<CarouselDemo />', () => {});
