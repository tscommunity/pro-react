import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {CarouselDemo} from './CarouselDemo';

const meta: Meta<typeof CarouselDemo> = {
  component: CarouselDemo,
};

export default meta;

type Story = StoryObj<typeof CarouselDemo>;

export const Basic: Story = {args: {}};
