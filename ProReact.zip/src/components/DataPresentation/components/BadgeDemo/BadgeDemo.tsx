import { useState } from 'react';
import { Badge, Space, Switch } from 'antd';
import { ClockCircleOutlined } from '@ant-design/icons';
import styles from './BadgeDemo.module.scss';

export interface BadgeDemoProps {
  prop?: string;
}

export function BadgeDemo({ prop = '徽标组件示例' }: Readonly<BadgeDemoProps>) {
  const [show, setShow] = useState(true);

  return <>
    <div className={styles.BadgeDemo}>BadgeDemo {prop}</div>

    <Space>
      <Switch checked={show} onChange={() => setShow(!show)} />
      <Badge count={show ? 11 : 0} showZero color="#faad14" />
      <Badge count={show ? 25 : 0} />
      <Badge count={show ? <ClockCircleOutlined style={{ color: '#f5222d' }} /> : 0} />
      <Badge
        className="site-badge-count-109"
        count={show ? 109 : 0}
        style={{ backgroundColor: '#52c41a' }}
      />
    </Space>
  </>;
}
