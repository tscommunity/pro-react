import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {BadgeDemo} from './BadgeDemo';

const meta: Meta<typeof BadgeDemo> = {
  component: BadgeDemo,
};

export default meta;

type Story = StoryObj<typeof BadgeDemo>;

export const Basic: Story = {args: {}};
