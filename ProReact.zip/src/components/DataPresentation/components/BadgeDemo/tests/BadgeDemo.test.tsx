import React from 'react';

import {BadgeDemo} from '../BadgeDemo';

describe('<BadgeDemo />', () => {});
