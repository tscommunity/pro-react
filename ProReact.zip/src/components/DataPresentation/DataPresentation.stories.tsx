import React from 'react';
import type {Meta, StoryObj} from '@storybook/react';

import {DataPresentation} from './DataPresentation';

const meta: Meta<typeof DataPresentation> = {
  component: DataPresentation,
};

export default meta;

type Story = StoryObj<typeof DataPresentation>;

export const Basic: Story = {args: {}};
